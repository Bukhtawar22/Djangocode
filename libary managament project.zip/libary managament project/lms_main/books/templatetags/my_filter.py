from django import template


register = template.Library()

def change_edition(value):
    if value == 1:
        return "First"
    return value

register.filter("change" , change_edition)