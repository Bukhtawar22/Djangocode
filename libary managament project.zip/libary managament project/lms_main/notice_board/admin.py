from django.contrib import admin
from notice_board.models import Notice
# Register your models here.
admin.site.register(Notice)