from django.shortcuts import render
from django.http import HttpResponse
from notice_board.models import Notice
# Create your views here.

def notice(request):
    data = Notice.objects.all()
    notice ={"details":data}
    return render(request , "noticeboard/notice.html" , context=notice)