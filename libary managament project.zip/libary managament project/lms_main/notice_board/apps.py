from django.apps import AppConfig


class NoticeBoardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'notice_board'
